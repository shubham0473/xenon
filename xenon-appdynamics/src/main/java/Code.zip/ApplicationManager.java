import com.vmware.xenon.common.Operation;
import com.vmware.xenon.common.OperationJoin;
import com.vmware.xenon.common.StatelessService;
import com.vmware.xenon.common.Utils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by agrawalshubham on 7/6/2016.
 */
public class ApplicationManager extends StatelessService {

    public static final String SELF_LINK = ServiceUrls.SERVICE_URI_APP_MANAGER;
//    public static final String FACTORY_LINK = ServiceUriPaths.CORE + ServiceUrls.SERVICE_URI_MANAGER;

    public static final String ACTION_INITIALIZE = "INITIALIZE";
    public static final String ACTION_LOAD_APPS = "LOAD-APPS";
    public static final String ACTION_SYNC = "SYNC";

    private volatile String authStr = null;

    //Fetches data from app dynamics api and for each app,
    //it posts to ApplicationDataCollectionService
    @Override
    public void handlePost(Operation op){
        logSevere("AM: In handle post");

        String requestString = op.getBody(String.class);
        JSONObject requestJson = new JSONObject(requestString);

        switch(requestJson.getString("action")){
            case ACTION_INITIALIZE:
                initialize(op);
                break;
            case ACTION_LOAD_APPS:
                if(authStr == null){
                    op.fail(Operation.STATUS_CODE_BAD_METHOD);
                    return;
                }
                loadApps(op);
                break;
            case ACTION_SYNC:
                break;
            default:
                logSevere("ACTION NOT SUPPORTED");
                op.fail(Operation.STATUS_CODE_BAD_METHOD);
                break;
        }


        op.complete();
    }

    private void initialize(Operation op) {
        String requestString = op.getBody(String.class);
        JSONObject requestJson  = new JSONObject(requestString);

        JSONObject credentialsJson = requestJson.getJSONObject("credentials");
        String credentials = credentialsJson.getString("username") + ":" + credentialsJson.getString("password");

        authStr = "Basic " + javax.xml.bind.DatatypeConverter.
                printBase64Binary(credentials.getBytes());
        op.complete();
        return;
    }


    public void loadApps(Operation op){
        List<Operation> postOp = new ArrayList<>();
        Operation getAppData = Operation
                .createGet(URI.create(ServiceUrls.APP_DYNAMICS_APP_API));
        getAppData.addRequestHeader(Operation.AUTHORIZATION_HEADER, authStr);
        getAppData.setBody(new Object());
        getAppData.setCompletion((getOp, failOp) -> {
            if (failOp != null) {
                Utils.toString(failOp);
                getAppData.fail(Operation.STATUS_CODE_BAD_REQUEST);
                return;
            } else {
                String response = getOp.getBody(String.class);
                if (response.compareTo("{}") == 0) {
                    getAppData.complete();
                    return;
                }
                JSONArray data = new JSONArray(response);


                for (int i = 0; i < data.length(); i++) {
                    if (data.getJSONObject(i) != null) {
                        System.out.println("data at " + i + "===" + data.getJSONObject(i).toString());
                        Operation post = Operation.createPost(URI.create("http://localhost:8001" + ServiceUrls.SERVICE_URI_APP_DATA));
                        post.addRequestHeader(Operation.AUTHORIZATION_HEADER, authStr);
                        post.setBody(data.getJSONObject(i).toString());
                        postOp.add(post);

                    }
                }
                OperationJoin.JoinedCompletionHandler jh = (ops, failures) -> {
                    if(failures != null){
                        op.fail(Operation.STATUS_CODE_INTERNAL_ERROR);
                    }
                    System.out.println("Successfully created Apps");
                    op.complete();
                };
                OperationJoin.create(postOp).setCompletion(jh).sendWith(this);
                return;
            }
        });

        this.sendRequest(getAppData);
    }


}
