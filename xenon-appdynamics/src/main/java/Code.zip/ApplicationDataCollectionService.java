import com.vmware.xenon.common.FactoryService;
import com.vmware.xenon.common.Operation;
import com.vmware.xenon.common.TaskState;
import com.vmware.xenon.common.Utils;
import com.vmware.xenon.services.common.TaskService;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.util.function.Consumer;

/**
 * Created by agrawalshubham on 7/6/2016.
 */
public class ApplicationDataCollectionService extends TaskService<Application> {

    public static final String FACTORY_LINK = ServiceUrls.SERVICE_URI_APP_DATA;
    public static final String SELF_LINK = ServiceUrls.SERVICE_URI_APP_DATA;


    public String username = "shubham@customer1";
    public String password = "paradiddle";
    public String credentials = username + ":" + password;
    public String authStr = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(credentials.getBytes());

    /**
     * Simple passthrough to our parent's constructor.
     *
     *
     */
    public ApplicationDataCollectionService() {
        super(Application.class);
        toggleOption(ServiceOption.PERSISTENCE, true);
        toggleOption(ServiceOption.REPLICATION, true);
        toggleOption(ServiceOption.INSTRUMENTATION, true);
        toggleOption(ServiceOption.OWNER_SELECTION, true);
    }

    /**
     * These substages helps in creating a FSM which triggers different routine on different states i.e substages
     */

    public static FactoryService createFactory() {
        return FactoryService.create(ApplicationDataCollectionService.class, ServiceOption.IDEMPOTENT_POST,
                ServiceOption.INSTRUMENTATION);
    }
//
//    protected Application validateStartPost(Operation taskOperation){
//        Application app = super.validateStartPost(taskOperation);
//        if(app == null){
//            return null;
//        }
//        if(ServiceHost.isServiceCreate(taskOperation)){
//            if(app.subStage != null){
//                taskOperation.fail(new IllegalArgumentException("Do not specify subStage: internal use only"));
//            }
//        }
//
//    @Override
//    public void handleCreate(Operation op){
//
//
//    }\

//    @Override
//    public void handleGet(Operation get){
//        System.out.println("in gett");
//        super.handleGet(get);
//        get.complete();
//    }


    //
    public void handleSubstage(Application app){
        System.out.println("App =" + app.toString());
        switch (app.subStage) {
            case INITIALIZED:
                logSevere("In init");
                getSelfInformation(app);
                break;
            case COLLECTING:
                logSevere("In collecting");
                System.out.println("app id == " + app.id);
//                sendSelfPatch(app);
                sendSignal(app.id);
                break;
            case COLLECTED:
                logSevere("In collected");
                break;
            default:
                logWarning("Unexpected sub stage: %s", app.subStage);
                break;
        }
    }

    //Send signal to TierManager with app id and self link
    public void sendSignal(int appId){
        JSONObject reqJson = new JSONObject();
        reqJson.put("id", appId);
        reqJson.put("parentSelfLink", this.getSelfLink());
        Operation op = Operation.createPost(URI.create(ServiceUrls.SERVICE_HOST + ServiceUrls.SERVICE_URI_TIER_MANAGER));
        op.addRequestHeader(Operation.AUTHORIZATION_HEADER, authStr);
        op.setReferer(this.getUri());
        System.out.println("req json =- " + reqJson.toString());
        op.setBody(reqJson.toString());
        op.setCompletion((postOp, failOp) -> {
            if (failOp != null) {
                System.out.println("in error: send fetch signal");
                Utils.toString(failOp);
                op.fail(Operation.STATUS_CODE_INTERNAL_ERROR);
                System.out.println(failOp.getMessage());

            } else {
                System.out.println("in success: send fetch signal");
                String response = postOp.getBody(String.class);
                System.out.println(response.toString());
                op.complete();
            }
        });
        this.sendRequest(op);
        return;
    }


    @Override
    protected void initializeState(Application app, Operation op){
        app.subStage = Application.SubStage.INITIALIZED;
        logSevere("In init state");

        super.initializeState(app, op);
    }

    //Get the data about itself from the appdynamics api
    public void getSelfInformation(Application app){
        System.out.println("id ===== " + app.id);
        Operation dataRequest = Operation
                .createGet(URI.create(ServiceUrls.APP_DYNAMICS_PER_APP_API + app.id + "?output=JSON"));
        dataRequest.addRequestHeader(Operation.AUTHORIZATION_HEADER, authStr);
        dataRequest.setBody(new Object());
        dataRequest.setReferer(this.getUri());
        dataRequest.setCompletion((getOp, failOp) -> {
            if (failOp != null) {
                Utils.toString(failOp);
                dataRequest.fail(Operation.STATUS_CODE_BAD_REQUEST);
                System.out.println(failOp.getMessage());
                return;
            } else {
                String data = getOp.getBody(String.class);
                JSONArray requestJson = new JSONArray(data);
                System.out.println(requestJson.getJSONObject(0).toString());
                sendSelfPatch(app, TaskState.TaskStage.STARTED, subStageSetter(Application.SubStage.COLLECTING));
                return;
            }
        });

        this.sendRequest(dataRequest);
    }


    @Override
    public void handlePatch(Operation patch){
        Application currentApp = getState(patch);
        Application patchBody = getBody(patch);

        //TODO: check if the transition is valid

        updateState(currentApp, patchBody);
        patch.complete();

        switch(patchBody.taskInfo.stage){
            case CREATED:
                break;
            case STARTED:
                handleSubstage(patchBody);
                break;
            case CANCELLED:
                logInfo("Request cancelled");
                break;
            case FINISHED:
                logInfo("Finished successfully");
                break;
            case FAILED:
                logWarning("Task failed: %s", (patchBody.failureMessage == null ? "No reason given"
                        : patchBody.failureMessage));
                break;
            default:
                logWarning("Unexpected stage: %s", patchBody.taskInfo.stage);
                break;
        }
    }



    private Consumer<Application> subStageSetter(Application.SubStage subStage) {
        return appState -> appState.subStage = subStage;
    }



}
