import com.vmware.xenon.common.FactoryService;
import com.vmware.xenon.common.Operation;
import com.vmware.xenon.common.TaskState;
import com.vmware.xenon.common.Utils;
import com.vmware.xenon.services.common.TaskService;
import org.json.JSONArray;

import java.net.URI;
import java.util.function.Consumer;

/**
 * Created by agrawalshubham on 7/9/2016.
 */
public class TierDataCollectionService extends TaskService<Tier> {

    public static final String FACTORY_LINK = ServiceUrls.SERVICE_URI_TIER_DATA;
    public static final String SELF_LINK = ServiceUrls.SERVICE_URI_TIER_DATA;


    public String username = "shubham@customer1";
    public String password = "paradiddle";
    public String credentials = username + ":" + password;
    public String authStr = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(credentials.getBytes());

    /**
     * Simple passthrough to our parent's constructor.
     *
     */
    public TierDataCollectionService() {
        super(Tier.class);
        toggleOption(ServiceOption.PERSISTENCE, true);
        toggleOption(ServiceOption.REPLICATION, true);
        toggleOption(ServiceOption.INSTRUMENTATION, true);
        toggleOption(ServiceOption.OWNER_SELECTION, true);
    }

    public static FactoryService createFactory() {
        return FactoryService.create(TierDataCollectionService.class, ServiceOption.IDEMPOTENT_POST,
                ServiceOption.INSTRUMENTATION);
    }

    @Override
    protected void initializeState(Tier tier, Operation op){
        tier.subStage = Tier.SubStage.INITIALIZED;
        super.initializeState(tier, op);
    }

//    public void getSelfInformation(Tier tier){
//
//    }

    public void handleSubstage(Tier tier){
        System.out.println("Tier Service: in handle Substage");
        switch(tier.subStage) {
            case INITIALIZED:
                System.out.println("Tier Service: in init");
                getSelfInformation(tier);
                break;
            case COLLECTING:
                System.out.println("In collecting");
                break;
            case COLLECTED:
                break;
            default:
                break;
        }
    }

    public void getSelfInformation(Tier tier){
        System.out.println(ServiceUrls.APP_DYNAMICS_PER_APP_API + ServiceUrls.APP_DYNAMICS_TIER_API + "/" + tier.tierId + "?output=JSON");
        Operation dataRequest = Operation
                .createGet(URI.create(ServiceUrls.APP_DYNAMICS_PER_APP_API + ServiceUrls.APP_DYNAMICS_TIER_API + tier.tierId + "?output=JSON"));
        dataRequest.addRequestHeader(Operation.AUTHORIZATION_HEADER, authStr);
        dataRequest.setBody(new Object());
        dataRequest.setReferer(this.getUri());
        dataRequest.setCompletion((getOp, failOp) -> {
            if (failOp != null) {

                System.out.println("Tier data: fail self info");
                Utils.toString(failOp);
                dataRequest.fail(Operation.STATUS_CODE_BAD_REQUEST);
                System.out.println(failOp.getMessage());
                return;
            } else {
                System.out.println("Tier data: success self info");
                String data = getOp.getBody(String.class);
                JSONArray requestJson = new JSONArray(data);
                System.out.println(requestJson.getJSONObject(0).toString());
                sendSelfPatch(tier, TaskState.TaskStage.STARTED, subStageSetter(Tier.SubStage.COLLECTING));
                return;
            }
        });

        this.sendRequest(dataRequest);
    }

    @Override
    public void handlePatch(Operation patch){
        Tier currentTier = getState(patch);
        Tier patchBody = getBody(patch);

        updateState(currentTier, patchBody);

        switch (patchBody.taskInfo.stage){
            case CREATED:
                break;
            case STARTED:
                handleSubstage(patchBody);
                break;
            case CANCELLED:
                break;
            case FINISHED:
                break;
            case FAILED:
                break;
            default:
                break;
        }
    }

    private Consumer<Tier> subStageSetter(Tier.SubStage subStage) {
        return tierState -> tierState.subStage = subStage;
    }



}
